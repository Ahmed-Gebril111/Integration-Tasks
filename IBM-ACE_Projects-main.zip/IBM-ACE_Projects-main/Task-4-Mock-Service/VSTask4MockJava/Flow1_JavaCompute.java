import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbPolicy;
import com.ibm.broker.plugin.MbUserException;

public class Flow1_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

	    MbMessage inMessage = inAssembly.getMessage();
	    MbMessage outMessage = new MbMessage(inMessage);
	    MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);

	    // ---- your policy-reading code goes here ----
	    MbPolicy myPol = getPolicy("UserDefined", "{VSTask4Policy}:Service1UDP");
	    String url = null;
	    if (myPol != null) {
	        url = myPol.getPropertyValueAsString("Mock1");
	    }
	    if (url == null) {
	        throw new MbUserException(this, "evaluate", "", "", "service1UDP.serviceUrl not found", null);
	    }

	    // ---- put the URL where HTTPAsyncRequest reads it from ----
	    MbElement outLocalEnv = outAssembly.getLocalEnvironment().getRootElement();

	    MbElement dest = outLocalEnv.getFirstElementByPath("Destination");
	    if (dest == null) {
	        dest = outLocalEnv.createElementAsLastChild(MbElement.TYPE_NAME, "Destination", null);
	    }

	    MbElement http = dest.getFirstElementByPath("HTTP");
	    if (http == null) {
	        http = dest.createElementAsLastChild(MbElement.TYPE_NAME, "HTTP", null);
	    }

	    MbElement existingUrl = http.getFirstElementByPath("RequestURL");
	    if (existingUrl != null) {
	        existingUrl.setValue(url);
	    } else {
	        http.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "RequestURL", url);
	    }

	    // ---- pass the message body through unchanged ----
	    // (outMessage was already created as a copy of inMessage above, so the body is already there)
	    
	 // ---- read the API key from the same policy ----
	    String apiKey = myPol.getPropertyValueAsString("ApiKey1");
	    if (apiKey == null) {
	        throw new MbUserException(this, "evaluate", "", "", "service1UDP.apiKey1 not found", null);
	    }

	    // ---- attach it as a request header ----
	    MbElement outRoot = outMessage.getRootElement();
	    MbElement httpReqHdr = outRoot.createElementAsFirstChild(MbElement.TYPE_NAME, "HTTPRequestHeader", null);
	    httpReqHdr.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "x-api-key", apiKey);

	    out.propagate(outAssembly);

	}

	/**
	 * onPreSetupValidation() is called during the construction of the node
	 * to allow the node configuration to be validated.  Updating the node
	 * configuration or connecting to external resources should be avoided.
	 *
	 * @throws MbException
	 */
	@Override
	public void onPreSetupValidation() throws MbException {
	}

	/**
	 * onSetup() is called during the start of the message flow allowing
	 * configuration to be read/cached, and endpoints to be registered.
	 *
	 * Calling getPolicy() within this method to retrieve a policy links this
	 * node to the policy. If the policy is subsequently redeployed the message
	 * flow will be torn down and reinitialized to it's state prior to the policy
	 * redeploy.
	 *
	 * @throws MbException
	 */
	@Override
	public void onSetup() throws MbException {
	}

	/**
	 * onStart() is called as the message flow is started. The thread pool for
	 * the message flow is running when this method is invoked.
	 *
	 * @throws MbException
	 */
	@Override
	public void onStart() throws MbException {
	}

	/**
	 * onStop() is called as the message flow is stopped. 
	 *
	 * The onStop method is called twice as a message flow is stopped. Initially
	 * with a 'wait' value of false and subsequently with a 'wait' value of true.
	 * Blocking operations should be avoided during the initial call. All thread
	 * pools and external connections should be stopped by the completion of the
	 * second call.
	 *
	 * @throws MbException
	 */
	@Override
	public void onStop(boolean wait) throws MbException {
	}

	/**
	 * onTearDown() is called to allow any cached data to be released and any
	 * endpoints to be deregistered.
	 *
	 * @throws MbException
	 */
	@Override
	public void onTearDown() throws MbException {
	}

}
